# Evaluation report

Computed from the exported CSVs only (no ground truth). Injected anomalies are included, so figures differ from a perfectly clean run by a fraction of a percent.

## Segment sizes (active memberships)

**snapshot_1_2026-08-01**

| segment | customers |
|---|---|
| LOYAL | 1,002 |
| HIBERNATING | 930 |
| AT_RISK | 901 |
| POTENTIAL_LOYALIST | 578 |
| PROSPECT | 564 |
| CHAMPIONS | 429 |
| NEW_CUSTOMER | 314 |
| HIGH_RETURNS | 147 |
| HIGH_SERVICE_COST | 134 |

**snapshot_2_2026-10-23**

| segment | customers |
|---|---|
| HIBERNATING | 1,150 |
| LOYAL | 1,100 |
| AT_RISK | 958 |
| CHAMPIONS | 570 |
| POTENTIAL_LOYALIST | 515 |
| NEW_CUSTOMER | 429 |
| PROSPECT | 293 |
| HIGH_RETURNS | 169 |
| HIGH_SERVICE_COST | 133 |

## Action funnel

| action | recommended | suppressed | holdout | sent | delivered | engaged/success | success | success rate |
|---|---|---|---|---|---|---|---|---|
| CROSS_SELL_BUNDLE | 571 | 135 | 48 | 388 | 373 | 161 | 34 | 0.0912 |
| LOYALTY_REWARD | 996 | 317 | 85 | 594 | 574 | 308 | 98 | 0.1707 |
| PROSPECT_NURTURE | 568 | 172 | 40 | 356 | 345 | 175 | 62 | 0.1797 |
| REACTIVATION_DISCOUNT_20 | 929 | 361 | 55 | 513 | 496 | 204 | 23 | 0.0464 |
| RETURN_POLICY_GUIDE | 147 | 46 | 0 | 101 | 97 | 94 | 92 | 0.9485 |
| SERVICE_OUTREACH_CALL | 134 | 18 | 0 | 116 | 110 | 97 | 92 | 0.8364 |
| VIP_EARLY_ACCESS | 431 | 114 | 40 | 277 | 265 | 162 | 69 | 0.2604 |
| WELCOME_SERIES | 318 | 94 | 21 | 203 | 194 | 102 | 38 | 0.1959 |
| WINBACK_OFFER_10 | 898 | 267 | 66 | 565 | 550 | 242 | 58 | 0.1055 |

## Uplift vs holdout (ORDER_14D actions)

| action | treated n | holdout n | treated CR | holdout CR | lift | 95% CI | incr. revenue / recipient |
|---|---|---|---|---|---|---|---|
| CROSS_SELL_BUNDLE | 373 | 48 | 9.12% | 12.50% | -3.38% | [-13.19%, +6.42%] | -5.78 |
| LOYALTY_REWARD | 574 | 85 | 17.07% | 8.24% | +8.84% | [+2.23%, +15.44%] | 6.71 |
| PROSPECT_NURTURE | 345 | 40 | 17.97% | 7.50% | +10.47% | [+1.36%, +19.58%] | 6.28 |
| REACTIVATION_DISCOUNT_20 | 496 | 55 | 4.64% | 12.73% | -8.09% | [-17.09%, +0.91%] | -7.68 |
| VIP_EARLY_ACCESS | 265 | 40 | 26.04% | 22.50% | +3.54% | [-10.44%, +17.52%] | 4.87 |
| WINBACK_OFFER_10 | 550 | 66 | 10.55% | 7.58% | +2.97% | [-3.91%, +9.85%] | 1.67 |

**Overall:** treated 13.66% vs holdout 10.99% (lift +2.67%, 95% CI [-0.82%, +6.16%]).

Decisions: {'SEND': 3113, 'SUPPRESS': 1524, 'HOLDOUT': 355} - suppression rate 30.5%.
