# Validation summary

**Overall: PASS** - 79/79 checks passed.

A check PASSES when everything it flags is a *labelled injected anomaly* (see `ground_truth/`) and every injected anomaly of its type is found; checks without a ground-truth issue type must flag nothing.

## Row counts

| table | rows |
|---|---|
| customers | 5,000 |
| products | 120 |
| orders | 20,000 |
| order_lines | 38,949 |
| engagement_events | 100,000 |
| support_cases | 6,000 |
| consents | 15,053 |
| segment_rules | 9 |
| segment_memberships | 7,924 |
| action_catalog | 9 |
| action_eligibility | 12 |
| action_outcomes | 4,992 |

## Injected anomaly detection

| issue type | injected | detected by |
|---|---|---|
| ACTION_VIOLATES_CONSENT | 15 | `CONTACT.consent_enforced` (found 15, missed 0) |
| CONFLICTING_EXCLUSIVE_SEGMENT | 15 | `RULES.membership_follows_rules` (found 15, missed 0); `RULES.exclusive_group_single` (found 30, missed 0) |
| OUTCOME_WRONG_ACTION | 15 | `ACTION.eligible_for_segment` (found 15, missed 0) |
| RETURN_NOT_NETTED | 15 | `MATH.membership_metrics` (found 15, missed 0); `MATH.membership_net_spend` (found 15, missed 0) |

## All checks

| check | category | flagged | expected (injected) | unexpected | missed | status |
|---|---|---|---|---|---|---|
| `PK_UNIQUE.customers` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.customers` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.products` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.products` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.orders` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.orders` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.order_lines` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.order_lines` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.engagement_events` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.engagement_events` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.support_cases` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.support_cases` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.consents` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.consents` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.segment_rules` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.segment_rules` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.segment_memberships` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.segment_memberships` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.action_catalog` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.action_catalog` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.action_eligibility` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.action_eligibility` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `PK_UNIQUE.action_outcomes` | primary_key | 0 | 0 | 0 | 0 | PASS |
| `SCHEMA.action_outcomes` | types_enums_required | 0 | 0 | 0 | 0 | PASS |
| `FK.orders.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.orders.parent_order_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.order_lines.order_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.order_lines.product_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.order_lines.parent_line_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.engagement_events.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.engagement_events.product_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.engagement_events.action_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.support_cases.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.support_cases.order_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.consents.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.segment_memberships.segment_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.segment_memberships.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_eligibility.segment_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_eligibility.catalog_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_outcomes.customer_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_outcomes.membership_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_outcomes.catalog_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `FK.action_outcomes.attributed_order_id` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `SQLITE.FK_CHECK` | foreign_key | 0 | 0 | 0 | 0 | PASS |
| `DATE.order_after_signup` | date_ordering | 0 | 0 | 0 | 0 | PASS |
| `LIFECYCLE.return_parent` | lifecycle | 0 | 0 | 0 | 0 | PASS |
| `MATH.line_amount` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `MATH.unit_price` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `MATH.line_sign` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `MATH.order_totals` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `MATH.return_qty` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `DATE.product_validity` | date_ordering | 0 | 0 | 0 | 0 | PASS |
| `MATH.case_cost` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `LIFECYCLE.case_dates` | date_ordering | 0 | 0 | 0 | 0 | PASS |
| `LIFECYCLE.consent_chain` | lifecycle | 0 | 0 | 0 | 0 | PASS |
| `DATE.events` | date_ordering | 0 | 0 | 0 | 0 | PASS |
| `MATH.customer_derived` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `LIFECYCLE.membership_dating` | lifecycle | 0 | 0 | 0 | 0 | PASS |
| `RULES.membership_follows_rules` | business_rule | 15 | 15 | 0 | 0 | PASS |
| `RULES.no_missing_membership` | business_rule | 0 | 0 | 0 | 0 | PASS |
| `RULES.exclusive_group_single` | business_rule | 30 | 30 | 0 | 0 | PASS |
| `MATH.membership_metrics` | reconciliation | 15 | 15 | 0 | 0 | PASS |
| `MATH.membership_net_spend` | reconciliation | 15 | 15 | 0 | 0 | PASS |
| `ACTION.eligible_for_segment` | business_rule | 15 | 15 | 0 | 0 | PASS |
| `ACTION.metric_matches_catalog` | business_rule | 0 | 0 | 0 | 0 | PASS |
| `ACTION.decision_consistency` | lifecycle | 0 | 0 | 0 | 0 | PASS |
| `CONTACT.channel_allowed` | contact_constraint | 0 | 0 | 0 | 0 | PASS |
| `CONTACT.consent_enforced` | contact_constraint | 15 | 15 | 0 | 0 | PASS |
| `CONTACT.frequency_cap` | contact_constraint | 0 | 0 | 0 | 0 | PASS |
| `CONTACT.open_case_suppression` | contact_constraint | 0 | 0 | 0 | 0 | PASS |
| `CONTACT.high_service_discount_block` | contact_constraint | 0 | 0 | 0 | 0 | PASS |
| `ACTION.holdout_scope` | business_rule | 0 | 0 | 0 | 0 | PASS |
| `OUTCOME.reevaluation` | reconciliation | 0 | 0 | 0 | 0 | PASS |
| `OUTCOME.status_coherent` | lifecycle | 0 | 0 | 0 | 0 | PASS |
| `DUP.segment_memberships` | duplicates | 0 | 0 | 0 | 0 | PASS |
| `DUP.action_outcomes` | duplicates | 0 | 0 | 0 | 0 | PASS |
| `DUP.consents` | duplicates | 0 | 0 | 0 | 0 | PASS |
| `DUP.order_lines` | duplicates | 0 | 0 | 0 | 0 | PASS |
| `DUP.action_eligibility` | duplicates | 0 | 0 | 0 | 0 | PASS |

## Scenario coverage

```json
{
  "customers_by_lifecycle_state": {
    "ACTIVE": 1830,
    "DORMANT": 1576,
    "AT_RISK": 873,
    "NEW": 428,
    "PROSPECT": 293
  },
  "new_customers(first_sale<=60d)": 428,
  "dormant_customers": 1576,
  "prospects": 293,
  "return_orders": 1500,
  "customers_with_returns": 1148,
  "high_service_cost_accounts(snapshot2)": 133,
  "consent_withdrawal_rows": 989,
  "customers_withdrawing_any_consent": 874,
  "open_support_cases": 131,
  "recency_boundary_days": {
    "30": 21,
    "31": 38,
    "60": 13,
    "61": 14,
    "120": 10,
    "121": 10,
    "240": 2,
    "241": 4
  },
  "decisions": {
    "SEND": 3113,
    "SUPPRESS": 1524,
    "HOLDOUT": 355
  },
  "suppression_reasons": {
    "NO_CONSENT": 1088,
    "CONSENT_WITHDRAWN": 288,
    "OPEN_SUPPORT_CASE": 88,
    "FREQUENCY_CAP": 32,
    "HIGH_SERVICE_COST_DISCOUNT_BLOCK": 28
  }
}
```
