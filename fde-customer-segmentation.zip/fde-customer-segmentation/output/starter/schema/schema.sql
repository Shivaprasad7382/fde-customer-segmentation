-- Generated from segmentation_gen.schema; SQLite / ANSI-friendly DDL

CREATE TABLE products (
  product_id TEXT NOT NULL,
  sku TEXT NOT NULL,
  product_name TEXT NOT NULL,
  category TEXT NOT NULL,
  subcategory TEXT NOT NULL,
  list_price NUMERIC NOT NULL,
  unit_cost NUMERIC NOT NULL,
  status TEXT NOT NULL,
  launch_date DATE NOT NULL,
  discontinued_date DATE,
  PRIMARY KEY (product_id)
);

CREATE TABLE customers (
  customer_id TEXT NOT NULL,
  signup_date DATE NOT NULL,
  region TEXT NOT NULL,
  acquisition_channel TEXT NOT NULL,
  age_band TEXT,
  preferred_channel TEXT NOT NULL,
  contact_frequency_cap_30d INTEGER NOT NULL,
  customer_type TEXT NOT NULL,
  lifecycle_state TEXT NOT NULL,
  first_order_date DATE,
  last_order_date DATE,
  lifetime_order_count INTEGER NOT NULL,
  lifetime_net_spend NUMERIC NOT NULL,
  PRIMARY KEY (customer_id)
);

CREATE TABLE orders (
  order_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  order_date DATE NOT NULL,
  order_type TEXT NOT NULL,
  parent_order_id TEXT,
  order_channel TEXT NOT NULL,
  gross_amount NUMERIC NOT NULL,
  discount_amount NUMERIC NOT NULL,
  net_amount NUMERIC NOT NULL,
  PRIMARY KEY (order_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (parent_order_id) REFERENCES orders(order_id)
);

CREATE TABLE order_lines (
  line_id TEXT NOT NULL,
  order_id TEXT NOT NULL,
  line_number INTEGER NOT NULL,
  product_id TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  unit_price NUMERIC NOT NULL,
  discount_pct NUMERIC NOT NULL,
  line_amount NUMERIC NOT NULL,
  parent_line_id TEXT,
  return_reason TEXT,
  PRIMARY KEY (line_id),
  FOREIGN KEY (order_id) REFERENCES orders(order_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id),
  FOREIGN KEY (parent_line_id) REFERENCES order_lines(line_id)
);

CREATE TABLE consents (
  consent_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  purpose TEXT NOT NULL,
  status TEXT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  source TEXT NOT NULL,
  PRIMARY KEY (consent_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE support_cases (
  case_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  order_id TEXT,
  opened_at TIMESTAMP NOT NULL,
  closed_at TIMESTAMP,
  category TEXT NOT NULL,
  priority TEXT NOT NULL,
  status TEXT NOT NULL,
  escalated INTEGER NOT NULL,
  handling_minutes INTEGER NOT NULL,
  cost_amount NUMERIC NOT NULL,
  PRIMARY KEY (case_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

CREATE TABLE segment_rules (
  segment_id TEXT NOT NULL,
  segment_code TEXT NOT NULL,
  segment_name TEXT NOT NULL,
  description TEXT NOT NULL,
  rule_type TEXT NOT NULL,
  exclusive_group TEXT NOT NULL,
  priority INTEGER NOT NULL,
  min_r INTEGER,
  max_r INTEGER,
  min_f INTEGER,
  max_f INTEGER,
  min_m INTEGER,
  max_m INTEGER,
  max_days_since_first_order INTEGER,
  min_cases_180d INTEGER,
  min_service_cost_ratio NUMERIC,
  min_return_rate NUMERIC,
  min_sale_orders INTEGER,
  version INTEGER NOT NULL,
  status TEXT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  PRIMARY KEY (segment_id)
);

CREATE TABLE segment_memberships (
  membership_id TEXT NOT NULL,
  segment_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  is_current INTEGER NOT NULL,
  recency_days INTEGER,
  frequency INTEGER NOT NULL,
  gross_spend NUMERIC NOT NULL,
  returned_amount NUMERIC NOT NULL,
  net_spend NUMERIC NOT NULL,
  r_score INTEGER NOT NULL,
  f_score INTEGER NOT NULL,
  m_score INTEGER NOT NULL,
  days_since_first_order INTEGER,
  cases_180d INTEGER NOT NULL,
  service_cost_180d NUMERIC NOT NULL,
  service_cost_ratio NUMERIC NOT NULL,
  return_rate NUMERIC NOT NULL,
  rule_version INTEGER NOT NULL,
  assignment_reason TEXT NOT NULL,
  PRIMARY KEY (membership_id),
  FOREIGN KEY (segment_id) REFERENCES segment_rules(segment_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE action_catalog (
  catalog_id TEXT NOT NULL,
  action_code TEXT NOT NULL,
  action_name TEXT NOT NULL,
  action_type TEXT NOT NULL,
  purpose TEXT NOT NULL,
  allowed_channels TEXT NOT NULL,
  is_discount INTEGER NOT NULL,
  discount_pct NUMERIC,
  success_metric TEXT NOT NULL,
  attribution_window_days INTEGER NOT NULL,
  requires_holdout INTEGER NOT NULL,
  cost_per_contact NUMERIC NOT NULL,
  status TEXT NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  PRIMARY KEY (catalog_id)
);

CREATE TABLE action_eligibility (
  eligibility_id TEXT NOT NULL,
  segment_id TEXT NOT NULL,
  catalog_id TEXT NOT NULL,
  priority INTEGER NOT NULL,
  effective_from DATE NOT NULL,
  effective_to DATE,
  PRIMARY KEY (eligibility_id),
  FOREIGN KEY (segment_id) REFERENCES segment_rules(segment_id),
  FOREIGN KEY (catalog_id) REFERENCES action_catalog(catalog_id)
);

CREATE TABLE action_outcomes (
  action_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  membership_id TEXT NOT NULL,
  catalog_id TEXT NOT NULL,
  recommended_at TIMESTAMP NOT NULL,
  decision TEXT NOT NULL,
  suppression_reason TEXT,
  channel TEXT,
  sent_at TIMESTAMP,
  delivery_status TEXT NOT NULL,
  success_metric TEXT NOT NULL,
  success_flag INTEGER,
  attributed_order_id TEXT,
  attributed_revenue NUMERIC,
  outcome_status TEXT NOT NULL,
  evaluated_at DATE NOT NULL,
  PRIMARY KEY (action_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (membership_id) REFERENCES segment_memberships(membership_id),
  FOREIGN KEY (catalog_id) REFERENCES action_catalog(catalog_id),
  FOREIGN KEY (attributed_order_id) REFERENCES orders(order_id)
);

CREATE TABLE engagement_events (
  event_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  event_ts TIMESTAMP NOT NULL,
  event_type TEXT NOT NULL,
  channel TEXT NOT NULL,
  product_id TEXT,
  action_id TEXT,
  PRIMARY KEY (event_id),
  FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
  FOREIGN KEY (product_id) REFERENCES products(product_id),
  FOREIGN KEY (action_id) REFERENCES action_outcomes(action_id)
);
