"""Single source of truth for the data model.

The same spec drives: the data dictionary (docs + CSV/JSON), SQL DDL, CSV column order,
and the generic type / enum / required / pattern checks in ``validate.py``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from . import config as C


@dataclass
class Field:
    name: str
    type: str                      # string | int | decimal | date | datetime | bool
    required: bool = True
    allowed: Optional[list] = None  # enum values
    pattern: Optional[str] = None   # regex for ids
    unit: str = ""
    unique: bool = False
    rule: str = ""                  # validation / derivation rule
    fk: Optional[str] = None        # "table.column"
    scale: int = 2                  # decimals for type == decimal
    derived: bool = False


@dataclass
class Table:
    name: str
    entity: str
    pk: str
    description: str
    cardinality: list
    fields: list = field(default_factory=list)

    def col(self, name):
        return next(f for f in self.fields if f.name == name)

    @property
    def columns(self):
        return [f.name for f in self.fields]


F = Field
U = "USD"

TABLES: dict[str, Table] = {}


def _t(t: Table):
    TABLES[t.name] = t
    return t


_t(Table("customers", "Customer", "customer_id",
         "One row per customer or prospect. Behavioural / lifecycle columns are derived from source records as of "
         "snapshot 2 (2026-10-23).",
         ["Customer 1:N Order", "Customer 1:N EngagementEvent", "Customer 1:N SupportCase",
          "Customer 1:N Consent", "Customer N:M SegmentRule via SegmentMembership",
          "Customer 1:N ActionOutcome"],
         [F("customer_id", "string", pattern=r"^CUS-\d{6}$", unique=True, rule="Immutable; sequential by sign-up date"),
          F("signup_date", "date", rule="2024-10-01 <= signup_date <= 2026-10-22"),
          F("region", "string", allowed=C.REGIONS),
          F("acquisition_channel", "string", allowed=C.ACQ_CHANNELS),
          F("age_band", "string", required=False, allowed=C.AGE_BANDS, rule="~8% missing (unknown)"),
          F("preferred_channel", "string", allowed=C.CHANNELS, rule="Contact preference; does NOT imply consent"),
          F("contact_frequency_cap_30d", "int", allowed=[1, 2, 3], unit="contacts / 30 days",
            rule="Max SEND decisions per customer per 30 days"),
          F("customer_type", "string", allowed=C.CUSTOMER_TYPES, derived=True,
            rule="PROSPECT iff lifetime_order_count = 0"),
          F("lifecycle_state", "string", allowed=C.LIFECYCLE_STATES, derived=True,
            rule="PROSPECT: 0 sales; NEW: first sale <= 60d before snapshot2; ACTIVE: last sale <= 90d; "
                 "AT_RISK: 91-180d; DORMANT: >180d"),
          F("first_order_date", "date", required=False, derived=True, rule="min(order_date) of SALE orders"),
          F("last_order_date", "date", required=False, derived=True, rule="max(order_date) of SALE orders"),
          F("lifetime_order_count", "int", derived=True, rule="count of SALE orders; >= 0"),
          F("lifetime_net_spend", "decimal", unit=U, derived=True,
            rule="sum(orders.net_amount) over SALE + RETURN orders (returns netted)")]))

_t(Table("products", "Product", "product_id",
         "Product master with a 2-level taxonomy (category > subcategory).",
         ["Product 1:N OrderLine", "Product 1:N EngagementEvent (optional)"],
         [F("product_id", "string", pattern=r"^PRD-\d{6}$", unique=True),
          F("sku", "string", unique=True, pattern=r"^SKU-[A-Z]{3}-\d{5}$"),
          F("product_name", "string"),
          F("category", "string", rule="8 top-level categories"),
          F("subcategory", "string"),
          F("list_price", "decimal", unit=U, rule="> 0"),
          F("unit_cost", "decimal", unit=U, rule="0 < unit_cost < list_price"),
          F("status", "string", allowed=C.PRODUCT_STATUS),
          F("launch_date", "date"),
          F("discontinued_date", "date", required=False,
            rule="Required iff status = DISCONTINUED; no order line after this date")]))

_t(Table("orders", "Order", "order_id",
         "Order header. SALE rows are purchases; RETURN rows are explicit return events linked to their SALE via "
         "parent_order_id (history is never overwritten; spend is netted by summing both).",
         ["Customer 1:N Order", "Order 1:N OrderLine", "SALE Order 1:N RETURN Order (optional, parent_order_id)"],
         [F("order_id", "string", pattern=r"^ORD-\d{4}-\d{6}$", unique=True,
            rule="ORD-<year of order_date>-<per-year counter>; IDs assigned in chronological order"),
          F("customer_id", "string", fk="customers.customer_id"),
          F("order_date", "date", rule=">= customer.signup_date; <= 2026-10-22"),
          F("order_type", "string", allowed=C.ORDER_TYPES),
          F("parent_order_id", "string", required=False, fk="orders.order_id",
            rule="Required iff RETURN; parent must be a SALE of the same customer dated before the return"),
          F("order_channel", "string", allowed=C.ORDER_CHANNELS),
          F("gross_amount", "decimal", unit=U, derived=True, rule="sum(quantity * unit_price) of lines"),
          F("discount_amount", "decimal", unit=U, derived=True, rule="gross_amount - net_amount"),
          F("net_amount", "decimal", unit=U, derived=True,
            rule="sum(line_amount); >0 for SALE, <0 for RETURN")]))

_t(Table("order_lines", "OrderLine", "line_id",
         "Bridge table resolving Order N:M Product. Return lines carry negative quantity / amount.",
         ["Order N:M Product via OrderLine", "SALE line 1:N RETURN line (optional, parent_line_id)"],
         [F("line_id", "string", pattern=r"^ORD-\d{4}-\d{6}-L\d{2}$", unique=True,
            rule="<order_id>-L<line_number zero-padded to 2>"),
          F("order_id", "string", fk="orders.order_id"),
          F("line_number", "int", rule=">= 1; unique within order"),
          F("product_id", "string", fk="products.product_id",
            rule="Product must be launched, and not discontinued, on order_date"),
          F("quantity", "int", unit="units", rule="!= 0; >0 for SALE, <0 for RETURN; |return qty| <= parent qty"),
          F("unit_price", "decimal", unit=U, rule="= products.list_price"),
          F("discount_pct", "decimal", unit="%", rule="0 <= x <= 50", scale=2),
          F("line_amount", "decimal", unit=U, derived=True,
            rule="round(quantity * unit_price * (1 - discount_pct/100), 2)"),
          F("parent_line_id", "string", required=False, fk="order_lines.line_id",
            rule="Required iff the order is a RETURN"),
          F("return_reason", "string", required=False, allowed=C.RETURN_REASONS, rule="Required iff RETURN line")]))

_t(Table("engagement_events", "EngagementEvent", "event_id",
         "Digital / messaging engagement events. Events caused by a campaign action reference action_id.",
         ["Customer 1:N EngagementEvent", "ActionOutcome 1:N EngagementEvent (optional)"],
         [F("event_id", "string", pattern=r"^EVT-\d{8}$", unique=True, rule="Chronological counter"),
          F("customer_id", "string", fk="customers.customer_id"),
          F("event_ts", "datetime", rule=">= signup_date 00:00:00; <= 2026-10-22 23:59:59"),
          F("event_type", "string", allowed=C.EVENT_TYPES),
          F("channel", "string", allowed=C.EVENT_CHANNELS),
          F("product_id", "string", required=False, fk="products.product_id",
            rule="Populated only for PRODUCT_VIEW / CART_ADD / WISHLIST_ADD"),
          F("action_id", "string", required=False, fk="action_outcomes.action_id",
            rule="Populated for opens/clicks caused by a SEND action; event_ts >= action sent_at")]))

_t(Table("support_cases", "SupportCase", "case_id",
         "Service cases. cost_amount is derived from handling time (agent cost) and escalation.",
         ["Customer 1:N SupportCase", "Order 1:N SupportCase (optional)"],
         [F("case_id", "string", pattern=r"^SUP-\d{6}$", unique=True),
          F("customer_id", "string", fk="customers.customer_id"),
          F("order_id", "string", required=False, fk="orders.order_id",
            rule="If present: same customer, order_date <= opened_at date"),
          F("opened_at", "datetime"),
          F("closed_at", "datetime", required=False, rule="Required iff status = CLOSED; >= opened_at"),
          F("category", "string", allowed=C.CASE_CATEGORIES),
          F("priority", "string", allowed=C.CASE_PRIORITIES),
          F("status", "string", allowed=C.CASE_STATUS, rule="OPEN iff closed_at is null"),
          F("escalated", "bool", rule="Only HIGH priority cases can be escalated"),
          F("handling_minutes", "int", unit="minutes", rule=">= 5"),
          F("cost_amount", "decimal", unit=U, derived=True,
            rule="round(handling_minutes/60 * 24.00 + 15.00 * escalated, 2)")]))

_t(Table("consents", "Consent", "consent_id",
         "Consent history as effective-dated rows (SCD type 2). A withdrawal closes the previous row and adds a new "
         "WITHDRAWN row; nothing is overwritten. No row for a customer/channel/purpose means no consent.",
         ["Customer 1:N Consent", "Customer N:M (channel, purpose) over time"],
         [F("consent_id", "string", pattern=r"^CON-\d{7}$", unique=True),
          F("customer_id", "string", fk="customers.customer_id"),
          F("channel", "string", allowed=C.CHANNELS),
          F("purpose", "string", allowed=C.CONSENT_PURPOSES),
          F("status", "string", allowed=C.CONSENT_STATUS,
            rule="Statuses alternate GRANTED/WITHDRAWN within customer+channel+purpose, starting with GRANTED"),
          F("effective_from", "date", rule=">= signup_date"),
          F("effective_to", "date", required=False,
            rule="Exclusive end; equals next row's effective_from; null on the current row"),
          F("source", "string", allowed=C.CONSENT_SOURCES)]))

_t(Table("segment_rules", "SegmentRule", "segment_id",
         "Declarative, versioned segment definitions. Exclusive-group rules are evaluated by ascending priority "
         "(first match wins); OVERLAY rules are independent flags. NULL bound = not applied.",
         ["SegmentRule N:M Customer via SegmentMembership", "SegmentRule N:M ActionCatalog via ActionEligibility"],
         [F("segment_id", "string", pattern=r"^SEG-2026-\d{6}$", unique=True),
          F("segment_code", "string", unique=True),
          F("segment_name", "string"),
          F("description", "string"),
          F("rule_type", "string", allowed=C.RULE_TYPES),
          F("exclusive_group", "string", allowed=C.EXCLUSIVE_GROUPS,
            rule="Customers may hold at most ONE active membership per exclusive group (NONE = overlay)"),
          F("priority", "int", rule="Lower number evaluated first"),
          F("min_r", "int", required=False, rule="0..5"), F("max_r", "int", required=False, rule="0..5"),
          F("min_f", "int", required=False, rule="0..5"), F("max_f", "int", required=False, rule="0..5"),
          F("min_m", "int", required=False, rule="0..5"), F("max_m", "int", required=False, rule="0..5"),
          F("max_days_since_first_order", "int", required=False, unit="days"),
          F("min_cases_180d", "int", required=False, unit="cases"),
          F("min_service_cost_ratio", "decimal", required=False, scale=4,
            rule="service_cost_180d / max(net_spend, 1)"),
          F("min_return_rate", "decimal", required=False, scale=4, rule="returned_amount / gross_spend"),
          F("min_sale_orders", "int", required=False, unit="orders"),
          F("version", "int"),
          F("status", "string", allowed=C.RULE_STATUS),
          F("effective_from", "date"),
          F("effective_to", "date", required=False)]))

_t(Table("segment_memberships", "SegmentMembership", "membership_id",
         "Bridge Customer N:M SegmentRule with effective dating. A row is opened when a customer enters a segment at a "
         "snapshot and closed when they leave. Metrics are those at effective_from (explainability).",
         ["Customer N:M SegmentRule via SegmentMembership", "SegmentMembership 1:N ActionOutcome"],
         [F("membership_id", "string", pattern=r"^MEM-SEG-2026-\d{6}-CUS-\d{6}$", unique=True,
            rule="MEM-<segment_id>-<customer_id>"),
          F("segment_id", "string", fk="segment_rules.segment_id"),
          F("customer_id", "string", fk="customers.customer_id"),
          F("effective_from", "date", allowed=["2026-08-01", "2026-10-23"], rule="Snapshot date"),
          F("effective_to", "date", required=False, rule="> effective_from; null when current"),
          F("is_current", "bool", derived=True, rule="1 iff effective_to is null"),
          F("recency_days", "int", required=False, unit="days", rule="snapshot - last SALE date; null if no sale"),
          F("frequency", "int", rule="count SALE orders dated < snapshot"),
          F("gross_spend", "decimal", unit=U, rule="sum SALE net_amount dated < snapshot"),
          F("returned_amount", "decimal", unit=U, rule="-sum RETURN net_amount dated < snapshot"),
          F("net_spend", "decimal", unit=U, derived=True, rule="gross_spend - returned_amount"),
          F("r_score", "int", rule="0 (no sale) or 1..5 per RECENCY_CUTS"),
          F("f_score", "int", rule="0 (no sale) or 1..5 per FREQUENCY_CUTS"),
          F("m_score", "int", rule="0 (no sale) or 1..5 per MONETARY_CUTS applied to net_spend"),
          F("days_since_first_order", "int", required=False, unit="days"),
          F("cases_180d", "int", rule="cases opened in [snapshot-180d, snapshot)"),
          F("service_cost_180d", "decimal", unit=U),
          F("service_cost_ratio", "decimal", scale=4, rule="service_cost_180d / max(net_spend, 1)"),
          F("return_rate", "decimal", scale=4, rule="returned_amount / gross_spend (0 if no spend)"),
          F("rule_version", "int"),
          F("assignment_reason", "string", rule="Human-readable explanation of why the rule matched")]))

_t(Table("action_catalog", "ActionCatalog", "catalog_id",
         "Catalogue of actions the business may take, with channel, consent purpose and suppression attributes.",
         ["ActionCatalog N:M SegmentRule via ActionEligibility", "ActionCatalog 1:N ActionOutcome"],
         [F("catalog_id", "string", pattern=r"^CAT-\d{4}$", unique=True),
          F("action_code", "string", unique=True),
          F("action_name", "string"),
          F("action_type", "string", allowed=C.ACTION_TYPES),
          F("purpose", "string", allowed=C.CONSENT_PURPOSES, rule="Consent purpose required to contact"),
          F("allowed_channels", "string", rule="Pipe-separated subset of EMAIL|SMS|PUSH|PHONE"),
          F("is_discount", "bool", rule="Discount actions are blocked for HIGH_SERVICE_COST accounts"),
          F("discount_pct", "decimal", required=False, unit="%"),
          F("success_metric", "string", allowed=C.SUCCESS_METRICS),
          F("attribution_window_days", "int", unit="days"),
          F("requires_holdout", "bool", rule="10% of otherwise-eligible customers are held out as control"),
          F("cost_per_contact", "decimal", unit=U),
          F("status", "string", allowed=C.RULE_STATUS),
          F("effective_from", "date"),
          F("effective_to", "date", required=False)]))

_t(Table("action_eligibility", "ActionEligibility", "eligibility_id",
         "Bridge SegmentRule N:M ActionCatalog. Lowest priority number is recommended first.",
         ["SegmentRule N:M ActionCatalog via ActionEligibility"],
         [F("eligibility_id", "string", pattern=r"^ELG-\d{4}$", unique=True),
          F("segment_id", "string", fk="segment_rules.segment_id"),
          F("catalog_id", "string", fk="action_catalog.catalog_id"),
          F("priority", "int", rule=">= 1; (segment_id, priority) unique"),
          F("effective_from", "date"),
          F("effective_to", "date", required=False)]))

_t(Table("action_outcomes", "ActionOutcome", "action_id",
         "One row per recommended action instance: the recommendation, the suppression / send decision and the "
         "evaluated outcome. Suppressed and held-out recommendations are logged too.",
         ["Customer 1:N ActionOutcome", "SegmentMembership 1:N ActionOutcome", "ActionCatalog 1:N ActionOutcome",
          "ActionOutcome 1:N EngagementEvent (optional)", "ActionOutcome 0..1:1 Order (attributed_order_id)"],
         [F("action_id", "string", pattern=r"^ACTN-2026-\d{6}$", unique=True,
            rule="ACTN-<year>-<counter>; chronological"),
          F("customer_id", "string", fk="customers.customer_id"),
          F("membership_id", "string", fk="segment_memberships.membership_id",
            rule="Membership (at recommendation time) that triggered the recommendation"),
          F("catalog_id", "string", fk="action_catalog.catalog_id",
            rule="Must be eligible for the membership's segment (action_eligibility)"),
          F("recommended_at", "datetime"),
          F("decision", "string", allowed=C.DECISIONS),
          F("suppression_reason", "string", required=False, allowed=C.SUPPRESSION_REASONS,
            rule="Required iff decision = SUPPRESS"),
          F("channel", "string", required=False, allowed=C.CHANNELS,
            rule="Required for SEND / HOLDOUT; must be in catalog.allowed_channels and consented"),
          F("sent_at", "datetime", required=False, rule="Required iff SEND; >= recommended_at"),
          F("delivery_status", "string", allowed=C.DELIVERY_STATUS),
          F("success_metric", "string", allowed=C.SUCCESS_METRICS, rule="= catalog.success_metric"),
          F("success_flag", "bool", required=False,
            rule="ORDER_14D: sale within 14d of sent_at (or recommended_at for HOLDOUT); CASE_FREE_30D: no case "
                 "opened within 30d; NO_RETURN_30D: no return within 30d. Null when suppressed / delivery failed"),
          F("attributed_order_id", "string", required=False, fk="orders.order_id",
            rule="ORDER_14D only: first SALE order inside the attribution window"),
          F("attributed_revenue", "decimal", required=False, unit=U, derived=True,
            rule="= attributed order net_amount"),
          F("outcome_status", "string", allowed=C.OUTCOME_STATUS),
          F("evaluated_at", "date", rule="Date outcomes were evaluated (2026-10-23)")]))

# load order respecting FKs
LOAD_ORDER = ["products", "customers", "orders", "order_lines", "consents", "support_cases", "segment_rules",
              "segment_memberships", "action_catalog", "action_eligibility", "action_outcomes",
              "engagement_events"]

_SQL_TYPES = {"string": "TEXT", "int": "INTEGER", "decimal": "NUMERIC", "date": "DATE",
              "datetime": "TIMESTAMP", "bool": "INTEGER"}


def ddl() -> str:
    out = ["-- Generated from segmentation_gen.schema; SQLite / ANSI-friendly DDL", ""]
    for name in LOAD_ORDER:
        t = TABLES[name]
        lines = []
        for f in t.fields:
            nn = " NOT NULL" if f.required else ""
            lines.append(f"  {f.name} {_SQL_TYPES[f.type]}{nn}")
        lines.append(f"  PRIMARY KEY ({t.pk})")
        for f in t.fields:
            if f.fk:
                tbl, col = f.fk.split(".")
                lines.append(f"  FOREIGN KEY ({f.name}) REFERENCES {tbl}({col})")
        out.append(f"CREATE TABLE {name} (\n" + ",\n".join(lines) + "\n);\n")
    return "\n".join(out)


FOREIGN_KEYS = [(t.name, f.name, *f.fk.split(".")) for t in TABLES.values() for f in t.fields if f.fk]


def dictionary_rows():
    rows = []
    for t in TABLES.values():
        for f in t.fields:
            rows.append({
                "table": t.name, "entity": t.entity, "field": f.name, "type": f.type,
                "required": f.required, "allowed_values": "|".join(map(str, f.allowed)) if f.allowed else "",
                "id_pattern": f.pattern or "", "unit": f.unit, "unique": f.unique or f.name == t.pk,
                "primary_key": f.name == t.pk, "foreign_key": f.fk or "", "derived": f.derived,
                "validation_rule": f.rule,
            })
    return rows


def dictionary_markdown() -> str:
    out = ["# Data dictionary", "",
           "Generated from `src/segmentation_gen/schema.py` (single source of truth). "
           "Types: `string`, `int`, `decimal` (2 dp unless stated), `date` (ISO 8601), `datetime` "
           "(`YYYY-MM-DD HH:MM:SS`, UTC, naive), `bool` (0/1). Money is in USD.", ""]
    for t in TABLES.values():
        out += [f"## {t.name} (entity: {t.entity})", "", t.description, "",
                f"**Primary key:** `{t.pk}`  ", "**Cardinality / relationships:**", ""]
        out += [f"- {c}" for c in t.cardinality]
        out += ["", "| Field | Type | Req. | Allowed values / pattern | Unit | Unique | FK | Derived | Validation rule |",
                "|---|---|---|---|---|---|---|---|---|"]
        for f in t.fields:
            allowed = "|".join(map(str, f.allowed)) if f.allowed else (f"`{f.pattern}`" if f.pattern else "")
            uniq = "yes" if (f.unique or f.name == t.pk) else ""
            out.append(f"| `{f.name}` | {f.type} | {'Y' if f.required else 'N'} | {allowed} | {f.unit} | {uniq} | "
                       f"{f.fk or ''} | {'Y' if f.derived else ''} | {f.rule} |")
        out.append("")
    return "\n".join(out)
