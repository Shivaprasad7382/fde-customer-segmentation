"""RFM features and the declarative segment rule engine.

Used by the generator *and* re-used by the validator on the exported CSV files, so a segment
assignment can always be re-derived from source records + the SegmentRule table.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config as C

# --------------------------------------------------------------------------------------
# Scoring bands
# --------------------------------------------------------------------------------------


def recency_score(days: np.ndarray) -> np.ndarray:
    """5 if <=30d, 4 if <=60, 3 if <=120, 2 if <=240, else 1 (0 when there is no sale)."""
    d = np.asarray(days, dtype="float64")
    s = 5 - np.searchsorted(C.RECENCY_CUTS, np.nan_to_num(d, nan=0.0), side="left")
    return np.where(np.isnan(d), 0, s).astype(int)


def frequency_score(freq: np.ndarray) -> np.ndarray:
    """1 order ->1, 2 ->2, 3-4 ->3, 5-7 ->4, >=8 ->5 (0 when no orders)."""
    f = np.asarray(freq)
    s = np.searchsorted(C.FREQUENCY_CUTS, f, side="right") + 1
    return np.where(f <= 0, 0, s).astype(int)


def monetary_score(net_spend: np.ndarray, freq: np.ndarray) -> np.ndarray:
    """<50 ->1, <150 ->2, <400 ->3, <1000 ->4, else 5 (0 when no orders)."""
    m = np.asarray(net_spend, dtype="float64")
    s = np.searchsorted(C.MONETARY_CUTS, m, side="right") + 1
    return np.where(np.asarray(freq) <= 0, 0, s).astype(int)


# --------------------------------------------------------------------------------------
# Rule table
# --------------------------------------------------------------------------------------
RULE_COLUMNS = ["segment_id", "segment_code", "segment_name", "description", "rule_type", "exclusive_group",
                "priority", "min_r", "max_r", "min_f", "max_f", "min_m", "max_m", "max_days_since_first_order",
                "min_cases_180d", "min_service_cost_ratio", "min_return_rate", "min_sale_orders", "version",
                "status", "effective_from", "effective_to"]


def build_rules() -> pd.DataFrame:
    eff = str(C.RULE_EFFECTIVE_FROM)
    spec = [
        # code, name, description, type, group, prio, bounds
        ("PROSPECT", "Prospect", "Signed up but no completed purchase before the snapshot.",
         "RFM", "LIFECYCLE_VALUE", 1, dict(max_f=0)),
        ("NEW_CUSTOMER", "New customer", "First purchase within the last 60 days.",
         "RFM", "LIFECYCLE_VALUE", 2, dict(min_f=1, max_days_since_first_order=60)),
        ("CHAMPIONS", "Champions", "Bought recently, often and with high net spend (R>=4, F>=4, M>=4).",
         "RFM", "LIFECYCLE_VALUE", 3, dict(min_r=4, min_f=4, min_m=4)),
        ("LOYAL", "Loyal", "Recent and repeat buyers (R>=3, F>=3).",
         "RFM", "LIFECYCLE_VALUE", 4, dict(min_r=3, min_f=3)),
        ("POTENTIAL_LOYALIST", "Potential loyalist", "Recent buyers with few orders so far (R>=3).",
         "RFM", "LIFECYCLE_VALUE", 5, dict(min_r=3)),
        ("AT_RISK", "At risk", "Last purchase 121-240 days ago (R=2).",
         "RFM", "LIFECYCLE_VALUE", 6, dict(min_r=2, max_r=2)),
        ("HIBERNATING", "Hibernating", "Last purchase more than 240 days ago (R=1).",
         "RFM", "LIFECYCLE_VALUE", 7, dict(min_r=1, max_r=1)),
        ("HIGH_SERVICE_COST", "High service cost",
         "At least 3 support cases in 180 days and service cost >= 10% of net spend.",
         "OVERLAY", "NONE", 1, dict(min_cases_180d=3, min_service_cost_ratio=0.10)),
        ("HIGH_RETURNS", "High returns",
         "At least 3 orders and returned value >= 30% of gross spend.",
         "OVERLAY", "NONE", 2, dict(min_return_rate=0.30, min_sale_orders=3)),
    ]
    rows = []
    for i, (code, name, desc, rtype, grp, prio, bounds) in enumerate(spec, start=1):
        r = {c: np.nan for c in RULE_COLUMNS}
        r.update(segment_id=f"SEG-2026-{i:06d}", segment_code=code, segment_name=name, description=desc,
                 rule_type=rtype, exclusive_group=grp, priority=prio, version=1, status="ACTIVE",
                 effective_from=eff, effective_to=None)
        r.update(bounds)
        rows.append(r)
    df = pd.DataFrame(rows, columns=RULE_COLUMNS)
    for c in ["min_r", "max_r", "min_f", "max_f", "min_m", "max_m", "max_days_since_first_order",
              "min_cases_180d", "min_sale_orders", "priority", "version"]:
        df[c] = df[c].astype("Int64")
    return df


# --------------------------------------------------------------------------------------
# Features
# --------------------------------------------------------------------------------------
FEATURE_COLUMNS = ["customer_id", "recency_days", "frequency", "gross_spend", "returned_amount", "net_spend",
                   "r_score", "f_score", "m_score", "days_since_first_order", "cases_180d",
                   "service_cost_180d", "service_cost_ratio", "return_rate"]


def compute_features(customers: pd.DataFrame, orders: pd.DataFrame, cases: pd.DataFrame,
                     snapshot) -> pd.DataFrame:
    """RFM + service + return features for every customer signed up on/before ``snapshot``.

    Only records dated strictly before the snapshot are used (no look-ahead).
    customers: customer_id, signup_date | orders: customer_id, order_date, order_type, net_amount |
    cases: customer_id, opened_at, cost_amount
    """
    t = pd.Timestamp(snapshot)
    cust = customers.loc[customers["signup_date"] <= t, ["customer_id"]].reset_index(drop=True)

    o = orders.loc[orders["order_date"] < t, ["customer_id", "order_date", "order_type", "net_amount"]]
    sales = o[o["order_type"] == "SALE"]
    g = sales.groupby("customer_id").agg(frequency=("net_amount", "size"), gross_spend=("net_amount", "sum"),
                                         first_order=("order_date", "min"), last_order=("order_date", "max"))
    rets = o[o["order_type"] == "RETURN"].groupby("customer_id")["net_amount"].sum().mul(-1).rename("returned_amount")

    lo = t - pd.Timedelta(days=C.SERVICE_WINDOW_DAYS)
    cs = cases.loc[(cases["opened_at"] >= lo) & (cases["opened_at"] < t)]
    cg = cs.groupby("customer_id").agg(cases_180d=("cost_amount", "size"), service_cost_180d=("cost_amount", "sum"))

    f = cust.merge(g, on="customer_id", how="left").merge(rets, on="customer_id", how="left") \
            .merge(cg, on="customer_id", how="left")
    for c in ["frequency", "gross_spend", "returned_amount", "cases_180d", "service_cost_180d"]:
        f[c] = f[c].fillna(0)
    f["frequency"] = f["frequency"].astype(int)
    f["cases_180d"] = f["cases_180d"].astype(int)
    f["gross_spend"] = f["gross_spend"].round(2)
    f["returned_amount"] = f["returned_amount"].round(2)
    f["net_spend"] = (f["gross_spend"] - f["returned_amount"]).round(2)
    f["service_cost_180d"] = f["service_cost_180d"].round(2)
    f["recency_days"] = (t - f["last_order"]).dt.days.astype("float64")
    f["days_since_first_order"] = (t - f["first_order"]).dt.days.astype("float64")
    f["r_score"] = recency_score(f["recency_days"].to_numpy())
    f["f_score"] = frequency_score(f["frequency"].to_numpy())
    f["m_score"] = monetary_score(f["net_spend"].to_numpy(), f["frequency"].to_numpy())
    f["service_cost_ratio"] = (f["service_cost_180d"] / np.maximum(f["net_spend"], 1.0)).round(4)
    f["return_rate"] = np.where(f["gross_spend"] > 0, f["returned_amount"] / f["gross_spend"].where(f["gross_spend"] > 0, 1.0), 0.0)
    f["return_rate"] = f["return_rate"].astype("float64").round(4)
    return f[FEATURE_COLUMNS]


# --------------------------------------------------------------------------------------
# Rule engine
# --------------------------------------------------------------------------------------
_BOUNDS = [("min_r", "r_score", ">="), ("max_r", "r_score", "<="), ("min_f", "f_score", ">="),
           ("max_f", "f_score", "<="), ("min_m", "m_score", ">="), ("max_m", "m_score", "<="),
           ("max_days_since_first_order", "days_since_first_order", "<="),
           ("min_cases_180d", "cases_180d", ">="), ("min_service_cost_ratio", "service_cost_ratio", ">="),
           ("min_return_rate", "return_rate", ">="), ("min_sale_orders", "frequency", ">=")]


def rule_mask(feats: pd.DataFrame, rule: pd.Series) -> np.ndarray:
    mask = np.ones(len(feats), dtype=bool)
    for bound, col, op in _BOUNDS:
        v = rule.get(bound)
        if v is None or pd.isna(v):
            continue
        x = feats[col].to_numpy(dtype="float64")
        mask &= (x >= float(v)) if op == ">=" else (x <= float(v))   # NaN compares False
    return mask


def active_rules(rules: pd.DataFrame, snapshot) -> pd.DataFrame:
    t = pd.Timestamp(snapshot)
    ef = pd.to_datetime(rules["effective_from"])
    et = pd.to_datetime(rules["effective_to"])
    ok = (rules["status"] == "ACTIVE") & (ef <= t) & (et.isna() | (et > t))
    return rules[ok]


def _reason(code, prio, ver, rt, row):
    if rt == "RFM":
        extra = "" if pd.isna(row[3]) else f", days_since_first_order={int(row[3])}"
        return (f"{code} (priority {prio}, rule v{ver}): R={row[0]} F={row[1]} M={row[2]}{extra}")
    return (f"{code} (overlay, rule v{ver}): cases_180d={row[4]}, service_cost_ratio={row[5]:.4f}, "
            f"return_rate={row[6]:.4f}, sale_orders={row[7]}")


def assign_segments(feats: pd.DataFrame, rules: pd.DataFrame, snapshot) -> pd.DataFrame:
    """Return one row per (customer, segment) with the metric snapshot and an explanation.

    Exclusive rules: evaluated by ascending priority, first match wins, exactly one per customer.
    Overlay rules: independent flags, a customer can match several.
    """
    rules = active_rules(rules, snapshot)
    n = len(feats)
    parts = []
    taken = np.zeros(n, dtype=bool)
    excl = rules[rules["exclusive_group"] != "NONE"].sort_values("priority")
    ovl = rules[rules["exclusive_group"] == "NONE"].sort_values("priority")
    matches = []
    for _, r in excl.iterrows():
        m = rule_mask(feats, r) & ~taken
        taken |= m
        matches.append((r, m))
    for _, r in ovl.iterrows():
        matches.append((r, rule_mask(feats, r)))
    cols = ["r_score", "f_score", "m_score", "days_since_first_order", "cases_180d", "service_cost_ratio",
            "return_rate", "frequency"]
    for r, m in matches:
        if not m.any():
            continue
        sub = feats.loc[m]
        arr = sub[cols].to_numpy(dtype="float64", na_value=np.nan)
        reasons = [_reason(r["segment_code"], int(r["priority"]), int(r["version"]), r["rule_type"],
                           [int(a[0]), int(a[1]), int(a[2]), a[3], int(a[4]), a[5], a[6], int(a[7])])
                   for a in arr]
        out = sub.copy()
        out["segment_id"] = r["segment_id"]
        out["rule_version"] = int(r["version"])
        out["assignment_reason"] = reasons
        parts.append(out)
    res = pd.concat(parts, ignore_index=True)
    res["membership_id"] = "MEM-" + res["segment_id"] + "-" + res["customer_id"]
    return res


def snapshot_memberships(customers, orders, cases, rules, snapshot) -> pd.DataFrame:
    feats = compute_features(customers, orders, cases, snapshot)
    m = assign_segments(feats, rules, snapshot)
    m["effective_from"] = pd.Timestamp(snapshot)
    return m
